import React from "react";

function TaskItem({ task, toggle, remove }) {
  return (
    <li className={`task-item ${task.completed ? "done" : ""}`}>
      <div>
        <strong>{task.title}</strong> ({task.subject})
        <div>Дедлайн: {task.deadline}</div>
      </div>

      <div className="actions">
        <button onClick={() => toggle(task.id)}>
          {task.completed ? "Вернуть" : "Выполнено"}
        </button>
        <button onClick={() => remove(task.id)}>Удалить</button>
      </div>
    </li>
  );
}

export default TaskItem;
