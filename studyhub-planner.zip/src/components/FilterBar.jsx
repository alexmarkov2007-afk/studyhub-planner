import React from "react";

function FilterBar({ tasks, setTasks }) {
  const showCompleted = () =>
    setTasks([...tasks].sort((a, b) => b.completed - a.completed));

  const reset = () =>
    setTasks([...tasks].sort((a, b) => a.id - b.id));

  return (
    <div className="filter-bar">
      <button onClick={reset}>По умолчанию</button>
      <button onClick={showCompleted}>Выполненные вверх</button>
    </div>
  );
}

export default FilterBar;
