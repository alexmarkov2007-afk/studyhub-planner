import React from "react";
import TaskItem from "./TaskItem";

function TaskList({ tasks, setTasks }) {
  const toggle = (id) =>
    setTasks(tasks.map(t => t.id === id ? { ...t, completed: !t.completed } : t));

  const remove = (id) =>
    setTasks(tasks.filter(t => t.id !== id));

  return (
    <ul className="task-list">
      {tasks.map(task => (
        <TaskItem key={task.id} task={task} toggle={toggle} remove={remove} />
      ))}
    </ul>
  );
}

export default TaskList;
