import React, { useState } from "react";

function TaskForm({ tasks, setTasks }) {
  const [title, setTitle] = useState("");
  const [subject, setSubject] = useState("");
  const [deadline, setDeadline] = useState("");

  const addTask = (e) => {
    e.preventDefault();
    if (!title.trim()) return;

    const newTask = {
      id: Date.now(),
      title,
      subject,
      deadline,
      completed: false,
    };

    setTasks([...tasks, newTask]);

    setTitle("");
    setSubject("");
    setDeadline("");
  };

  return (
    <form className="task-form" onSubmit={addTask}>
      <input type="text" placeholder="Название задачи" value={title}
        onChange={(e) => setTitle(e.target.value)} />

      <input type="text" placeholder="Предмет" value={subject}
        onChange={(e) => setSubject(e.target.value)} />

      <input type="date" value={deadline}
        onChange={(e) => setDeadline(e.target.value)} />

      <button type="submit">Добавить</button>
    </form>
  );
}

export default TaskForm;
